﻿namespace OTUS_L15_HW
{
    internal interface IChargeable
    {
        void Charge()
        {
            throw new NotImplementedException();
        }
        string GetInfo()
        {
            throw new NotImplementedException();
        }
    }
}
